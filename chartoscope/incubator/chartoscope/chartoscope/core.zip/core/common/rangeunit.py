class RangeUnit:
    def __init__(self, units):
        self.units= units

class RangeInterval:
    R1 = RangeUnit(1)
    R2 = RangeUnit(2)
    R3 = RangeUnit(3)
    R4 = RangeUnit(4)
    R5 = RangeUnit(5)
    R6 = RangeUnit(6)
    R7 = RangeUnit(7)
    R8 = RangeUnit(8)
    R9 = RangeUnit(9)
    R10 = RangeUnit(10)