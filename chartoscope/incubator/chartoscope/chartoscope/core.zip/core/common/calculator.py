class Calculator:

    def is_primed(self):
        return False
