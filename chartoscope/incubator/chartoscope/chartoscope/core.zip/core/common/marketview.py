from enum import Enum


class MarketView(Enum):
    Neutral = 0
    Bullish = 1
    Bearish = 2
