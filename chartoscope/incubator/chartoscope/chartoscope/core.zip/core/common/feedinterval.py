class FeedInterval:
    def __init__(self, interval):
        self.interval = interval
