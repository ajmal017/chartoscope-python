class SignalAdvisor:
    def __init__(self):
        pass

    def start(self):
        pass

    def stop(self):
        pass

