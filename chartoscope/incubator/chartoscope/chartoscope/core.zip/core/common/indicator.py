class Indicator:
    def __init__(self):
        pass

    def calculate(self, timestamp_value, value):
        pass
